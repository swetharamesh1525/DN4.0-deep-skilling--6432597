import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LibraryTest {
    public static void main(String[] args) {
        System.out.println("Spring Context Project Setup is Working!");
    }
}

