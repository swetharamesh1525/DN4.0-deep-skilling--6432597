package com.cognizant.orm_learn;

import com.cognizant.orm_learn.model.Country;
import com.cognizant.orm_learn.service.CountryService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;
@SpringBootApplication
public class OrmLearnApplication {

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
        CountryService service = context.getBean(CountryService.class);

        testFindCountriesByName(service);
    }

    private static void testFindCountriesByName(CountryService service) {
        System.out.println("Countries containing 'Uni':");
        List<Country> countries = service.findCountriesByName("Uni");
        countries.forEach(System.out::println);
    }
}

