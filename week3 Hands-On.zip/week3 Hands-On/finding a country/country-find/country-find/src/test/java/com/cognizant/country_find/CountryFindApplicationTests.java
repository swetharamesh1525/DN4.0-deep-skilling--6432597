package com.cognizant.country_find;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryFindApplicationTests {

	@Test
	void contextLoads() {
	}

}
