package com.sms.librarymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInitializrApplicationTests {

    @Test
    void contextLoads() {
    }

}
