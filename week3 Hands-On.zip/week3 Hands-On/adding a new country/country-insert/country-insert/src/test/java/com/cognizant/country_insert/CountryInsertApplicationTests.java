package com.cognizant.country_insert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryInsertApplicationTests {

	@Test
	void contextLoads() {
	}

}
