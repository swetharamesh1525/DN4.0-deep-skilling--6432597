package com.sms.service;

import com.sms.repository.BookRepository;
import java.util.List;

public class BookService {
    private BookRepository bookRepository;  // Constructor-injected
    private String libraryName;             // Setter-injected

    // Constructor Injection
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Setter Injection
    public void setLibraryName(String libraryName) {
        this.libraryName = libraryName;
    }

    public void displayBookDetails() {
        System.out.println("Welcome to " + libraryName);
        List<String> books = bookRepository.getAllBooks();
        System.out.println("Total books available: " + books.size());
        for (String book : books) {
            System.out.println("- " + book);
        }
    }
}
