package com.cognizant.countryquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryqueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
