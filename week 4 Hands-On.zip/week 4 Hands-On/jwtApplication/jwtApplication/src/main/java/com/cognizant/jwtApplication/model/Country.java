package com.cognizant.jwtApplication.model;
public class Country {
    private String code;
    private String name;

    // getters and setters
}
