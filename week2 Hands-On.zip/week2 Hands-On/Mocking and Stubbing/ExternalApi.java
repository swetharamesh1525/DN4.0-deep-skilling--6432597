public interface ExternalApi {
    String getData();
}
